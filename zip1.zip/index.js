// index.js
// ------------------------------------------------------------------
//
/* jshint esversion:9, node:true, strict:implied */
/* global process, console, Buffer */

const functions = require('@google-cloud/functions-framework');
const AdmZip   = require('adm-zip');

const base64Decode = (encoded) => Buffer.from(encoded.trim(), 'base64');

// Register an HTTP function with the Functions Framework
functions.http('zip-ops-handler', (req, res) => {
  // This is an Express middlware
  // Can access the req.body and req.rawBody objects here
  const bufferForDecodedFile = base64Decode(req.rawBody),
        zip = new AdmZip(bufferForDecodedFile),
        zipEntries = zip.getEntries();
  let result =
    zipEntries.map(entry => ({
      name: entry.entryName,
      contents: entry.getData().toString('base64')
    }));

  // Send an HTTP response
  res.send(JSON.stringify({result}));
});
